import{aX as t}from"./index-wRztDkWH.js";const s=()=>t.get("/statistics/overview"),i=()=>t.get("/statistics/disease"),r=()=>t.get("/statistics/trend");export{r as a,i as b,s as g};
