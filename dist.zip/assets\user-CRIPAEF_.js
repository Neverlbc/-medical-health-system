import{aX as e}from"./index-wRztDkWH.js";const s=t=>e.get("/user/patients",{params:{keyword:t,pageNum:1,pageSize:20}}),n=t=>e.get(`/patient/info/user/${t}`);export{n as g,s};
